<?php
/*
Plugin Name: Simple Google Maps Shortcode
Plugin URI: http://www.nioya.com/
Description: An easy way to create google maps with a marker and embed them in your posts, pages or custom post types. That's it
Version: 1.0
Author: Emrah Onder
Author URI: http://www.nioya.com
License: GPLv2 or later
*/
function nioya_google_maps_shortcode( $atts) {
	extract( shortcode_atts( array(
		'latlon' => '38.41904030551062, 27.12848961353302',
		'zoom' => '18',
		'html' => '<center>'.get_bloginfo().'</center>',
		'pin' => 'N',
		'title' => get_bloginfo()
	), $atts ) );
	$result = '';
	$result .= '<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript">

	function initialize() {
		var myLatlng = new google.maps.LatLng('.$latlon.');
		
		var myOptions = {
		  zoom: '.$zoom.',
		  center: myLatlng,
		  mapTypeId: google.maps.MapTypeId.HYBRID 
		}
		var map = new google.maps.Map(document.getElementById("targetMap"), myOptions);
		var infowindow = new google.maps.InfoWindow({
			content: \''.$html.'\'
		});
		
		var marker = new google.maps.Marker({
			position: myLatlng, 
			map: map,
			title:"'.$title.'",
			icon:"http://www.google.com/mapfiles/marker'.strtoupper($pin).'.png"
		});   
		google.maps.event.addListener(marker, \'click\', function() {
		  infowindow.open(map,marker);
		});
	}
	google.maps.event.addDomListener(window, \'load\', initialize);
	</script>';
	$result .= ' <div id="targetMap" style="width: 100%; height: 400px;"></div>';
	return $result;
}
add_shortcode( 'nioya-google-maps-shortcode', 'nioya_google_maps_shortcode' );
?>
